import json
from time import sleep
import requests
from datetime import datetime, timedelta
import calendar
import os
import dataModule
import dateModules
import sys


# tickers = ["NIFTY","BANKNIFTY","ADANIENT","ASHOKLEY","ASIANPAINT","AUROPHARMA","AXISBANK","BAJAJ-AUTO","BAJFINANCE","BANKBARODA","BHARTIARTL","BIOCON","BPCL","CANBK","COALINDIA","DLF","DRREDDY","FEDERALBNK","GAIL","GRASIM","HAVELLS","HCLTECH","HDFC","HDFCBANK","HEROMOTOCO","HINDALCO","HINDPETRO","HINDUNILVR","ICICIBANK","IDEA","INDIGO","INDUSINDBK","INFY","IOC","ITC","JINDALSTEL","JSWSTEEL","KOTAKBANK","LT","M&M","MARUTI","ONGC","PNB","PVR","RELIANCE","SAIL","SBIN","SUNPHARMA","TATACONSUM","TATAPOWER","TATASTEEL","TATAMOTORS","TCS","TITAN","UPL","VEDL","WIPRO","ZEEL"]
allExpiries = [
    "07MAR2019",
    "14MAR2019",
    "20MAR2019",
    "04APR2019",
    "11APR2019",
    "18APR2019",
    "02MAY2019",
    "09MAY2019",
    "16MAY2019",
    "23MAY2019",
    "06JUN2019",
    "13JUN2019",
    "20JUN2019",
    "04JUL2019",
    "11JUL2019",
    "18JUL2019",
    "01AUG2019",
    "08AUG2019",
    "14AUG2019",
    "22AUG2019",
    "05SEP2019",
    "12SEP2019",
    "19SEP2019",
    "03OCT2019",
    "10OCT2019",
    "17OCT2019",
    "24OCT2019",
    "07NOV2019",
    "14NOV2019",
    "21NOV2019",
    "05DEC2019",
    "12DEC2019",
    "19DEC2019",
    "02JAN2020",
    "09JAN2020",
    "16JAN2020",
    "23JAN2020",
    "06FEB2020",
    "13FEB2020",
    "20FEB2020",
    "05MAR2020",
    "12MAR2020",
    "19MAR2020",
    "01APR2020",
    "09APR2020",
    "16APR2020",
    "23APR2020",
    "07MAY2020",
    "14MAY2020",
    "21MAY2020",
    "04JUN2020",
    "11JUN2020",
    "18JUN2020",
    "02JUL2020",
    "09JUL2020",
    "16JUL2020",
    "23JUL2020",
    "06AUG2020",
    "13AUG2020",
    "20AUG2020",
    "03SEP2020",
    "10SEP2020",
    "17SEP2020",
    "01OCT2020",
    "08OCT2020",
    "15OCT2020",
    "22OCT2020",
    "05NOV2020",
    "12NOV2020",
    "19NOV2020",
    "03DEC2020",
    "10DEC2020",
    "17DEC2020",
    "24DEC2020",
    "07JAN2021",
    "14JAN2021",
    "21JAN2021",
    "04FEB2021",
    "11FEB2021",
    "18FEB2021",
    "04MAR2021",
    "10MAR2021",
    "18MAR2021",
    "01APR2021",
    "08APR2021",
    "15APR2021",
    "22APR2021",
    "06MAY2021",
    "12MAY2021",
    "20MAY2021",
    "03JUN2021",
    "10JUN2021",
    "17JUN2021",
    "01JUL2021",
    "08JUL2021",
    "15JUL2021",
    "22JUL2021",
    "05AUG2021",
    "12AUG2021",
    "18AUG2021",
    "02SEP2021",
    "09SEP2021",
    "16SEP2021",
    "23SEP2021",
    "07OCT2021",
    "14OCT2021",
    "21OCT2021",
    "03NOV2021",
    "11NOV2021",
    "18NOV2021",
    "02DEC2021",
    "09DEC2021",
    "16DEC2021",
    "23DEC2021",
    "06JAN2022",
]

tickers = ["NIFTY", "BANKNIFTY"]

expiries = slice(int(sys.argv[1]), int(sys.argv[1]) + 5, 1)
print(allExpiries[expiries])

for ticker in tickers:
    print(ticker)
    if not os.path.exists("Fetched/" + ticker):
        os.makedirs("Fetched/" + ticker)
    for expiry in allExpiries[expiries]:
        requests.get(
            "https://script.google.com/macros/s/AKfycbxbSOjvHNgLcxP0wqKAATDmuCSDpAj1mbfLuoultrWGPZlY-Lkm76vNuqaN5Jc8VQC0/exec?ticker="
            + ticker
            + "&expiry="
            + expiry
            + "&status=started"
        )
        if not os.path.exists("Fetched/" + ticker + "/" + expiry):
            os.makedirs("Fetched/" + ticker + "/" + expiry)
            startTime = dateModules.getStartTime(expiry)
            endTime = dateModules.getEndTime(expiry)
            while startTime <= endTime:
                if dateModules.isValid(startTime):
                    result = dataModule.fetchData(ticker, expiry, startTime)
                    startTime += 300
                else:
                    startTime = dateModules.getNextValidTime(startTime)
        requests.get(
            "https://script.google.com/macros/s/AKfycbxbSOjvHNgLcxP0wqKAATDmuCSDpAj1mbfLuoultrWGPZlY-Lkm76vNuqaN5Jc8VQC0/exec?ticker="
            + ticker
            + "&expiry="
            + expiry
            + "&status=completed"
        )


# Get Request
# If success then return fetched and store file as json in drive


# Weeklies - 50 days
# Monthly - 90 Days
# Quaterly - Year


# Tracking files done by splitting expiries
# 150 5
# 140 5
# 135 5
