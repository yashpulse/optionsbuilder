import requests
import json
import time


def fetchData(tick, exp, ts):
    url = "https://opstra.definedge.com/api/optionsimulator/optionchain/%s&%s&%s" % (
        ts,
        tick,
        exp,
    )
    fData = requests.get(
        url,
        headers={
            "accept": "application/json, text/plain, */*",
            "accept-language": "en-US,en;q=0.9",
            "cache-control": "no-cache",
            "pragma": "no-cache",
            "sec-ch-ua": '" Not;A Brand";v="99", "Google Chrome";v="97", "Chromium";v="97"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "Referer": "https://opstra.definedge.com/options-simulator",
            "Referrer-Policy": "strict-origin-when-cross-origin",
        },
    )
    if fData.status_code == 200:
        print(fData.status_code)
        with open(
            "Fetched/" + tick + "/" + exp + "/" + str(ts), "w", encoding="utf-8"
        ) as f:
            json.dump(fData.json(), f)
        time.sleep(0.8)
        return "Fetched"
    elif fData.status_code == 403:
        requests.get(
            "https://script.google.com/macros/s/AKfycbxbSOjvHNgLcxP0wqKAATDmuCSDpAj1mbfLuoultrWGPZlY-Lkm76vNuqaN5Jc8VQC0/exec?ticker="
            + tick
            + "&expiry="
            + exp
            + "&status=blocked"
            + "&timestamp="
            + ts
        )
        time.sleep(600)
        return "Failed"
    else:
        time.sleep(0.8)
        return "Failed"
