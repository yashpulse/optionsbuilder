import json
from time import sleep
import requests
from datetime import datetime, timedelta
import calendar
import os
import dataModule
import dateModules
import sys

completed = {
    "AXISBANK": {
        "30MAY2019": "completed",
        "31JAN2019": "completed",
        "27JUN2019": "completed",
        "28FEB2019": "completed",
        "25JUL2019": "completed",
        "28MAR2019": "completed",
        "29AUG2019": "completed",
        "25APR2019": "completed",
    },
    "ADANIENT": {
        "31JAN2019": "completed",
        "30MAY2019": "completed",
        "26SEP2019": "completed",
        "30JAN2020": "completed",
        "28MAY2020": "completed",
        "24SEP2020": "completed",
        "28JAN2021": "completed",
        "27MAY2021": "completed",
        "30SEP2021": "completed",
        "27JUN2019": "completed",
        "25JUN2020": "completed",
        "25JUL2019": "completed",
        "28FEB2019": "completed",
        "28MAR2019": "completed",
        "29OCT2020": "completed",
        "29AUG2019": "completed",
        "25APR2019": "completed",
        "28OCT2021": "completed",
        "24JUN2021": "completed",
        "25FEB2021": "completed",
        "31OCT2019": "completed",
        "27FEB2020": "completed",
        "30JUL2020": "completed",
        "26NOV2020": "completed",
        "27AUG2020": "completed",
        "31DEC2020": "completed",
        "25NOV2021": "completed",
        "28NOV2019": "completed",
        "29JUL2021": "completed",
        "25MAR2021": "completed",
        "26MAR2020": "completed",
        "30DEC2021": "completed",
        "26DEC2019": "completed",
        "29APR2021": "completed",
        "26AUG2021": "completed",
        "30APR2020": "completed",
    },
    "BANKNIFTY": {
        "28MAR2019": "completed",
        "24SEP2020": "completed",
        "27JUN2019": "completed",
        "31DEC2020": "completed",
        "26SEP2019": "completed",
        "25MAR2021": "completed",
        "26DEC2019": "completed",
        "24JUN2021": "completed",
        "26MAR2020": "completed",
        "30SEP2021": "completed",
        "25JUN2020": "completed",
        "30DEC2021": "completed",
    },
    "ASIANPAINT": {
        "30MAY2019": "completed",
        "31JAN2019": "completed",
        "27JUN2019": "completed",
        "28FEB2019": "completed",
        "25JUL2019": "completed",
        "28MAR2019": "completed",
        "29AUG2019": "completed",
        "25APR2019": "completed",
        "28MAY2020": "completed",
        "24SEP2020": "completed",
        "25JUN2020": "completed",
        "29OCT2020": "completed",
        "30JUL2020": "completed",
        "26NOV2020": "completed",
        "27AUG2020": "completed",
        "31DEC2020": "completed",
        "30SEP2021": "completed",
        "26SEP2019": "completed",
        "28JAN2021": "completed",
        "27MAY2021": "completed",
        "30JAN2020": "completed",
        "28OCT2021": "completed",
    },
    "AUROPHARMA": {
        "30MAY2019": "completed",
        "31JAN2019": "completed",
        "27JUN2019": "completed",
        "28FEB2019": "completed",
        "25JUL2019": "completed",
        "28MAR2019": "completed",
        "29AUG2019": "completed",
        "25APR2019": "completed",
        "28MAY2020": "completed",
        "24SEP2020": "completed",
        "25JUN2020": "completed",
        "29OCT2020": "completed",
        "30JUL2020": "completed",
        "26NOV2020": "completed",
        "27AUG2020": "completed",
    },
    "BAJFINANCE": {
        "30MAY2019": "completed",
        "31JAN2019": "completed",
        "27JUN2019": "completed",
        "28FEB2019": "completed",
        "25JUL2019": "completed",
        "28MAR2019": "completed",
        "29AUG2019": "completed",
        "25APR2019": "completed",
    },
    "BANKBARODA": {
        "30MAY2019": "completed",
        "31JAN2019": "completed",
        "27JUN2019": "completed",
        "28FEB2019": "completed",
        "25JUL2019": "completed",
        "28MAR2019": "completed",
    },
    "ASHOKLEY": {
        "30MAY2019": "completed",
        "31JAN2019": "completed",
        "27JUN2019": "completed",
        "28FEB2019": "completed",
        "25JUL2019": "completed",
        "28MAR2019": "completed",
        "29AUG2019": "completed",
        "25APR2019": "completed",
        "28MAY2020": "completed",
        "24SEP2020": "completed",
        "25JUN2020": "completed",
        "29OCT2020": "completed",
        "30JUL2020": "completed",
        "26NOV2020": "completed",
        "30SEP2021": "completed",
        "26SEP2019": "completed",
        "27AUG2020": "completed",
        "28JAN2021": "completed",
        "27MAY2021": "completed",
        "30JAN2020": "completed",
        "31DEC2020": "completed",
        "28OCT2021": "completed",
        "31OCT2019": "completed",
        "25FEB2021": "completed",
        "24JUN2021": "completed",
        "27FEB2020": "completed",
        "25NOV2021": "completed",
        "28NOV2019": "completed",
        "25MAR2021": "completed",
        "29JUL2021": "completed",
        "26MAR2020": "completed",
        "30DEC2021": "completed",
        "26DEC2019": "completed",
        "29APR2021": "completed",
        "26AUG2021": "completed",
        "30APR2020": "completed",
    },
    "BAJAJ-AUTO": {
        "30MAY2019": "completed",
        "31JAN2019": "completed",
        "27JUN2019": "completed",
        "28FEB2019": "completed",
        "25JUL2019": "completed",
        "28MAR2019": "completed",
        "29AUG2019": "completed",
        "25APR2019": "completed",
    },
}


tickers = [
    "ADANIENT",
    "ASHOKLEY",
    "ASIANPAINT",
    "AUROPHARMA",
    "AXISBANK",
    "BAJAJ-AUTO",
    "BAJFINANCE",
    "BANKBARODA",
    "BHARTIARTL",
    "BIOCON",
    "BPCL",
    "CANBK",
    "COALINDIA",
    "DLF",
    "DRREDDY",
    "FEDERALBNK",
    # "GAIL",
    # "GRASIM",
    # "HAVELLS",
    # "HCLTECH",
    # "HDFC",
    # "HDFCBANK",
    # "HEROMOTOCO",
    # "HINDALCO",
    # "HINDPETRO",
    # "HINDUNILVR",
    # "ICICIBANK",
    # "IDEA",
    # "INDIGO",
    # "INDUSINDBK",
    # "INFY",
    # "IOC",
    # "ITC",
    # "JINDALSTEL",
    # "JSWSTEEL",
    # "KOTAKBANK",
    # "LT",
    # "M&M",
    # "MARUTI",
    # "ONGC",
    # "PNB",
    # "PVR",
    # "RELIANCE",
    # "SAIL",
    # "SBIN",
    # "SUNPHARMA",
    # "TATACONSUM",
    # "TATAPOWER",
    # "TATASTEEL",
    # "TATAMOTORS",
    # "TCS",
    # "TITAN",
    # "UPL",
    # "VEDL",
    # "WIPRO",
    # "ZEEL",
]
allExpiries = [
    "31JAN2019",
    "28FEB2019",
    "28MAR2019",
    "25APR2019",
    "30MAY2019",
    "27JUN2019",
    "25JUL2019",
    "29AUG2019",
    "26SEP2019",
    "31OCT2019",
    "28NOV2019",
    "26DEC2019",
    "30JAN2020",
    "27FEB2020",
    "26MAR2020",
    "30APR2020",
    "28MAY2020",
    "25JUN2020",
    "30JUL2020",
    "27AUG2020",
    "24SEP2020",
    "29OCT2020",
    "26NOV2020",
    "31DEC2020",
    "28JAN2021",
    "25FEB2021",
    "25MAR2021",
    "29APR2021",
    "27MAY2021",
    "24JUN2021",
    "29JUL2021",
    "26AUG2021",
    "30SEP2021",
    "28OCT2021",
    "25NOV2021",
    "30DEC2021",
]

expiries = slice(int(sys.argv[1]), int(sys.argv[1]) + 3, 1)
print(allExpiries[expiries])


def executeFunction(ti, ex):
    requests.get(
        "https://script.google.com/macros/s/AKfycbyf_klSfIsqHHgv3p6dHtEVjdEKc_KqeG-4isjrN7RgLuWlWphyoDtuFphn5fk7zFZf/exec?ticker="
        + ti
        + "&expiry="
        + ex
        + "&status=started"
    )
    if not os.path.exists("Fetched/" + ti + "/" + ex):
        os.makedirs("Fetched/" + ti + "/" + ex)
        startTime = dateModules.getStartTime(ex)
        endTime = dateModules.getEndTime(ex)
        while startTime <= endTime:
            if dateModules.isValid(startTime):
                result = dataModule.fetchData(ti, ex, startTime)
                startTime += 300
            else:
                startTime = dateModules.getNextValidTime(startTime)
    requests.get(
        "https://script.google.com/macros/s/AKfycbyf_klSfIsqHHgv3p6dHtEVjdEKc_KqeG-4isjrN7RgLuWlWphyoDtuFphn5fk7zFZf/exec?ticker="
        + ti
        + "&expiry="
        + ex
        + "&status=completed"
    )


for ticker in tickers:
    print(ticker)
    if not os.path.exists("Fetched/" + ticker):
        os.makedirs("Fetched/" + ticker)
    for expiry in allExpiries[expiries]:
        if ticker in completed:
            if expiry in completed[ticker]:
                print("Don Not Run")
            else:
                executeFunction(ticker, expiry)
        else:
            executeFunction(ticker, expiry)


# Get Request
# If success then return fetched and store file as json in drive


# Weeklies - 50 days
# Monthly - 90 Days
# Quaterly - Year


# Tracking files done by splitting expiries
# 150 5
# 140 5
# 135 5
