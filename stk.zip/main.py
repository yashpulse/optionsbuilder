import json
from time import sleep
import requests
from datetime import datetime, timedelta
import calendar
import os
import dataModule
import dateModules
import sys


tickers = [
    "ADANIENT",
    "ASHOKLEY",
    "ASIANPAINT",
    "AUROPHARMA",
    "AXISBANK",
    "BAJAJ-AUTO",
    "BAJFINANCE",
    "BANKBARODA",
    "BHARTIARTL",
    "BIOCON",
    "BPCL",
    "CANBK",
    "COALINDIA",
    "DLF",
    "DRREDDY",
    "FEDERALBNK",
    # "GAIL",
    # "GRASIM",
    # "HAVELLS",
    # "HCLTECH",
    # "HDFC",
    # "HDFCBANK",
    # "HEROMOTOCO",
    # "HINDALCO",
    # "HINDPETRO",
    # "HINDUNILVR",
    # "ICICIBANK",
    # "IDEA",
    # "INDIGO",
    # "INDUSINDBK",
    # "INFY",
    # "IOC",
    # "ITC",
    # "JINDALSTEL",
    # "JSWSTEEL",
    # "KOTAKBANK",
    # "LT",
    # "M&M",
    # "MARUTI",
    # "ONGC",
    # "PNB",
    # "PVR",
    # "RELIANCE",
    # "SAIL",
    # "SBIN",
    # "SUNPHARMA",
    # "TATACONSUM",
    # "TATAPOWER",
    # "TATASTEEL",
    # "TATAMOTORS",
    # "TCS",
    # "TITAN",
    # "UPL",
    # "VEDL",
    # "WIPRO",
    # "ZEEL",
]
allExpiries = [
    "31JAN2019",
    "28FEB2019",
    "28MAR2019",
    "25APR2019",
    "30MAY2019",
    "27JUN2019",
    "25JUL2019",
    "29AUG2019",
    "26SEP2019",
    "31OCT2019",
    "28NOV2019",
    "26DEC2019",
    "30JAN2020",
    "27FEB2020",
    "26MAR2020",
    "30APR2020",
    "28MAY2020",
    "25JUN2020",
    "30JUL2020",
    "27AUG2020",
    "24SEP2020",
    "29OCT2020",
    "26NOV2020",
    "31DEC2020",
    "28JAN2021",
    "25FEB2021",
    "25MAR2021",
    "29APR2021",
    "27MAY2021",
    "24JUN2021",
    "29JUL2021",
    "26AUG2021",
    "30SEP2021",
    "28OCT2021",
    "25NOV2021",
    "30DEC2021",
]

expiries = slice(int(sys.argv[1]), int(sys.argv[1]) + 4, 1)
print(allExpiries[expiries])

for ticker in tickers:
    print(ticker)
    if not os.path.exists("Fetched/" + ticker):
        os.makedirs("Fetched/" + ticker)
    for expiry in allExpiries[expiries]:
        requests.get(
            "https://script.google.com/macros/s/AKfycbyf_klSfIsqHHgv3p6dHtEVjdEKc_KqeG-4isjrN7RgLuWlWphyoDtuFphn5fk7zFZf/exec?ticker="
            + ticker
            + "&expiry="
            + expiry
            + "&status=started"
        )
        if not os.path.exists("Fetched/" + ticker + "/" + expiry):
            os.makedirs("Fetched/" + ticker + "/" + expiry)
            startTime = dateModules.getStartTime(expiry)
            endTime = dateModules.getEndTime(expiry)
            while startTime <= endTime:
                if dateModules.isValid(startTime):
                    result = dataModule.fetchData(ticker, expiry, startTime)
                    startTime += 300
                else:
                    startTime = dateModules.getNextValidTime(startTime)
        requests.get(
            "https://script.google.com/macros/s/AKfycbyf_klSfIsqHHgv3p6dHtEVjdEKc_KqeG-4isjrN7RgLuWlWphyoDtuFphn5fk7zFZf/exec?ticker="
            + ticker
            + "&expiry="
            + expiry
            + "&status=completed"
        )


# Get Request
# If success then return fetched and store file as json in drive


# Weeklies - 50 days
# Monthly - 90 Days
# Quaterly - Year


# Tracking files done by splitting expiries
# 150 5
# 140 5
# 135 5
