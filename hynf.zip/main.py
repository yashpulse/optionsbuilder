import json
from time import sleep
import requests
from datetime import datetime, timedelta
import calendar
import os
import dataModule
import dateModules
import sys


# tickers = ["NIFTY","BANKNIFTY","ADANIENT","ASHOKLEY","ASIANPAINT","AUROPHARMA","AXISBANK","BAJAJ-AUTO","BAJFINANCE","BANKBARODA","BHARTIARTL","BIOCON","BPCL","CANBK","COALINDIA","DLF","DRREDDY","FEDERALBNK","GAIL","GRASIM","HAVELLS","HCLTECH","HDFC","HDFCBANK","HEROMOTOCO","HINDALCO","HINDPETRO","HINDUNILVR","ICICIBANK","IDEA","INDIGO","INDUSINDBK","INFY","IOC","ITC","JINDALSTEL","JSWSTEEL","KOTAKBANK","LT","M&M","MARUTI","ONGC","PNB","PVR","RELIANCE","SAIL","SBIN","SUNPHARMA","TATACONSUM","TATAPOWER","TATASTEEL","TATAMOTORS","TCS","TITAN","UPL","VEDL","WIPRO","ZEEL"]
allExpiries = [
    "27JUN2019",
    "26DEC2019",
    "25JUN2020",
    "31DEC2020",
    "24JUN2021",
    "30DEC2021",
]

tickers = ["NIFTY"]

expiries = slice(int(sys.argv[1]), int(sys.argv[1]) + 1, 1)
print(allExpiries[expiries])

for ticker in tickers:
    print(ticker)
    if not os.path.exists("Fetched/" + ticker):
        os.makedirs("Fetched/" + ticker)
    for expiry in allExpiries[expiries]:
        requests.get(
            "https://script.google.com/macros/s/AKfycbz4YAE1H6VTwrq3HbtB4om5ctRU57kkPdqB9PZSzbT7Wt_DyqK7rzLZE-LhDpUYuh9U/exec?ticker="
            + ticker
            + "&expiry="
            + expiry
            + "&status=started"
        )
        if not os.path.exists("Fetched/" + ticker + "/" + expiry):
            os.makedirs("Fetched/" + ticker + "/" + expiry)
            startTime = dateModules.getStartTime(expiry)
            endTime = dateModules.getEndTime(expiry)
            while startTime <= endTime:
                if dateModules.isValid(startTime):
                    result = dataModule.fetchData(ticker, expiry, startTime)
                    startTime += 300
                else:
                    startTime = dateModules.getNextValidTime(startTime)
        requests.get(
            "https://script.google.com/macros/s/AKfycbz4YAE1H6VTwrq3HbtB4om5ctRU57kkPdqB9PZSzbT7Wt_DyqK7rzLZE-LhDpUYuh9U/exec?ticker="
            + ticker
            + "&expiry="
            + expiry
            + "&status=completed"
        )


# Get Request
# If success then return fetched and store file as json in drive


# Weeklies - 50 days
# Monthly - 90 Days
# Quaterly - Year


# Tracking files done by splitting expiries
# 150 5
# 140 5
# 135 5
