import calendar
from datetime import datetime, timedelta

holidayList = [
    "432019",
    "2132019",
    "1742019",
    "1942019",
    "2942019",
    "152019",
    "562019",
    "1282019",
    "1582019",
    "292019",
    "1092019",
    "2102019",
    "8102019",
    "21102019",
    "28102019",
    "12112019",
    "25122019",
    "2122020",
    "1032020",
    "242020",
    "642020",
    "1042020",
    "1442020",
    "152020",
    "2552020",
    "2102020",
    "16112020",
    "30112020",
    "25122020",
    "2612021",
    "1132021",
    "2932021",
    "242021",
    "1442021",
    "2142021",
    "1352021",
    "2172021",
    "1982021",
    "1092021",
    "15102021",
    "4112021",
    "5112021",
    "19112021",
]
getMonth = {
    "JAN": 1,
    "FEB": 2,
    "MAR": 3,
    "APR": 4,
    "MAY": 5,
    "JUN": 6,
    "JUL": 7,
    "AUG": 8,
    "SEP": 9,
    "OCT": 10,
    "NOV": 11,
    "DEC": 12,
}


def getStartTimeStamp(yr, mn, dy):
    return calendar.timegm(datetime(int(yr), int(mn), int(dy), 3, 50).timetuple())


def getEndTimeStamp(yr, mn, dy):
    return calendar.timegm(datetime(int(yr), int(mn), int(dy), 10, 00).timetuple())


def changeDays(ts, dy):
    return str(datetime.fromtimestamp(ts) + timedelta(days=dy)).split(" ")[0].split("-")


def getStartTime(exp):
    year = exp[-4:]
    month = getMonth[exp[2:][:3]]
    day = exp[:2][1] if exp[:2][0] == "0" else exp[:2]
    x = changeDays(getStartTimeStamp(year, month, day), -365)
    return getStartTimeStamp(x[0], x[1], x[2])


def getEndTime(exp):
    year = exp[-4:]
    month = getMonth[exp[2:][:3]]
    day = exp[:2][1] if exp[:2][0] == "0" else exp[:2]
    x = changeDays(getStartTimeStamp(year, month, day), 0)
    return getEndTimeStamp(x[0], x[1], x[2])


def isValid(ts):
    if datetime.fromtimestamp(ts).isoweekday() > 5:
        return False
    y = changeDays(ts, 0)
    dtstr = str(int(y[2])) + str(int(y[1])) + str(int(y[0]))
    if dtstr in holidayList:
        return False
    currDayStart = getStartTimeStamp(y[0], y[1], y[2])
    currDayEnd = getEndTimeStamp(y[0], y[1], y[2])
    if int(ts) > currDayEnd or int(ts) < currDayStart:
        return False
    return True


# def getNextValidTime(ts):
def getNextValidTime(ts):
    nxtDay = changeDays(ts, 1)
    return getStartTimeStamp(nxtDay[0], nxtDay[1], nxtDay[2])
