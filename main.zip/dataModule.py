import requests
import json
import time
import random

# proxyList = [
#     "209.127.191.180:9279",
#     "45.95.96.132:8691",
#     "45.95.96.187:8746",
#     "45.95.96.237:8796",
#     "193.8.127.189:9271",
#     "45.94.47.66:8110",
#     "45.94.47.108:8152",
#     "193.8.56.119:9183",
#     "45.95.99.226:7786",
#     "45.95.99.20:7580",
# ]


def fetchData(tick, exp, ts):
    url = "https://opstra.definedge.com/api/optionsimulator/optionchain/%s&%s&%s" % (
        ts,
        tick,
        exp,
    )
    # print(url)
    # https_proxy = random.choice(proxyList)
    fData = requests.get(
        url,
        headers={
            "accept": "application/json, text/plain, */*",
            "accept-language": "en-US,en;q=0.9",
            "cache-control": "no-cache",
            "pragma": "no-cache",
            "sec-ch-ua": '" Not;A Brand";v="99", "Google Chrome";v="97", "Chromium";v="97"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "Referer": "https://opstra.definedge.com/options-simulator",
            "Referrer-Policy": "strict-origin-when-cross-origin",
        },
        # proxies={"https": https_proxy},
        # timeout=5,
    )
    if fData.status_code == 200:
        print(fData.status_code)
        with open(
            "Fetched/" + tick + "/" + exp + "/" + str(ts), "w", encoding="utf-8"
        ) as f:
            json.dump(fData.json(), f)
        time.sleep(0.6)
        return "Fetched"
    elif fData.status_code == 403:
        time.sleep(600)
        return "Failed"
    else:
        # print(fData.status_code, url)
        time.sleep(0.6)
        return "Failed"
